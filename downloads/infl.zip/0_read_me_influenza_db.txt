﻿/*___________________________________________________________________________*/
/*									     */
/*				READ ME					     */
/*___________________________________________________________________________*/

Her finder du en beskrivelse af indeholdet af zip-filen til SSI's Influenza 
dashboard, herunder beskrivelser af tabellerne med tilhørende variabelnavne 
(søjlenavne).

Opdateret: 2023-03-27

Generel struktur:
_______________________________________________________________________________
Rækkerne i filerne er som udgangspunkt stratificeringer efter relevante 
parametre, eksempelvis aldersgruppering eller tidsopdeling. Filerne er 
semicolon-separerede.


Opdateringer:
_______________________________________________________________________________
Filerne bliver opdateret ugentlig om onsdagen. I den forbindelse kan tidsserier også 
ændre sig tilbage i tiden, hvis nyere data foreligger. Derfor anbefales det 
altid at benytte det senest tilgængelige data og så vidt muligt, 
ikke at gemme filer og lave tidsserier på basis af gamle filer.


Bemærk:
_______________________________________________________________________________
Vær opmærksom på, at datagrundlaget for nye indlæggelser nogle dage ikke kan opdateres.
Det skyldes tekniske udfordringer hos en ekstern leverandør.
Samlet betyder det, at der på nuværende tidspunkt kan være en større dag-til-dag variation af de daglige indlæggelsestal.


Filerne:
_______________________________________________________________________________


Fil: 01_influenza_noegletal_saeson_region_agegrp
------------------------------------------------------------------------------
Denne benyttes til at beregne nøgletal for hele sæsonen og siden sidste opdatering

Kolonner:
Dato: Dato for udgivelse af data
Sidste opdatering: Dato der sammenlignes med når der skrives "siden sidste opdatering"
Sygdom: INFL=influenza A+B, INFLA=influenza A, INFLB=influenza B
Sæson: Influenza sæson
Regionskode: Regionskode for bopælsregionen på prøvedato
Region: Bopælsregion på prøvedato inkl. "Alle" (alle regioner)
Aldersgruppe: 0-2, 3-5, 6-11, 12-15, 16-19, 20-39, 40-64, 65-79, 80+ år
Køn: M=mand, K=kvinde, alle=samlet M+K	
Antal førstegangstestede personer: Antal tests hvor personer kun forekommer ved første test
Antal tests: Antallet af tests foretaget (OBS! hvis der er foretaget flere tests pr. dag pr. person så tæller kun en med) 
Antal Bekræftede tilfælde: Antal bekræftede tilfælde
Antal nye indlæggelser: Antal nye indlæggelser
Antal døde: Antal døde
Antal borgere: Population opgjort pr seneste opdatering fra CPR
Incidens: Antal bekræftede tilfælde divideret med den givne befolkningsstørrelse ganget med 100.000.
timestamp: tidsstempel for dataoprettelse i headeren


Fil: 02_influenza_epikurve_season_region_uge_agegrp 
------------------------------------------------------------------------------
Denne benyttes til at beregne søjlediagrammer (epikurver diverse)

Kolonner:
Sygdom: INFL=influenza A+B, INFLA=influenza A, INFLB=influenza B
Sæson: Influenza sæson
Uge: Uge
Regionskode: Regionskode for bopælsregionen på prøvedato
Region: Bopælsregion på prøvedato inkl. "Alle" (alle regioner)
Aldersgruppe: 0-2, 3-5, 6-11, 12-15, 16-19, 20-39, 40-64, 65-79, 80+ år
Køn: M=mand, K=kvinde, alle=samlet M+K
Antal borgere: Antal borgere
Antal tests: Antal testede personer
Antal Bekræftede tilfælde: Antal bekræftede tilfælde	
Antal nye indlæggelser: Antal nye indlæggelser
Antal døde: Antal døde
Positivprocent: Antal bekræftede tilfælde divideret med antallet af testede personer
Bekræftede tilfælde pr. 100.000 borgere: Antal bekræftede tilfælde divideret med den givne befolkningsstørrelse ganget med 100.000
Antal tests pr. 100.000 borgere: Antal tests divideret med den givne befolkningstørrelse ganget med 100.000
Nye indlæggelser pr. 100.000 borgere: Antal nye indlæggelser divideret med den givne befolkningsstørrelse ganget med 100.000
timestamp: tidsstempel for dataoprettelse i headeren

Fil: 04_influenza_maps_region_agegrp_sex_7days
------------------------------------------------------------------------------
Denne benyttes til at generere diverse kort

Kolonner:
Sygdom: INFL=influenza A+B, INFLA=influenza A, INFLB=influenza B
Regionskode: Regionskode for bopælsregionen på prøvedato
Region: Bopælsregion pr. dags dato inkl. "Alle" (alle regioner)			
Aldersgruppe: 0-2, 3-5, 6-11, 12-15, 16-19, 20-39, 40-64, 65-79, 80+ år
Køn: M=mand, K=kvinde, alle=samlet M+K
Antal borgere: Antal borgere
Antal testede personer: Antal tests (7 dage)* (se teksten under 'Bemærk')
Antal Bekræftede tilfælde: Antal bekræftede tilfælde (7 dage)
Antal nye indlæggelser: Antal nye indlæggelser (7 dage)
Antal døde: Antal døde (7 dage)
Positivprocent: Positivprocent (7 dage)
Bekræftede tilfælde pr. 100.000 borgere: Bekræftede tilfælde pr. 100.000 borgere (7 dage)
Testede personer pr. 100.000 borgere: Testede personer pr. 100.000 borgere (7 dage)
Nye indlæggelser pr. 100.000 borgere: Nye indlæggelser pr. 100.000 borgere (7 dage)
timestamp: tidsstempel for dataoprettelse i headeren