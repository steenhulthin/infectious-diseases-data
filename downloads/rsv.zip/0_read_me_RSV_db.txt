﻿/*___________________________________________________________________________*/
/*									     */
/*				READ ME					     */
/*___________________________________________________________________________*/

Her finder du en beskrivelse af indeholdet af zip-filen til SSI's RSV 
dashboard, herunder beskrivelser af tabellerne med tilhørende variabelnavne 
(søjlenavne).

Opdateret: 2023-03-28

Generel struktur:
_______________________________________________________________________________
Rækkerne i filerne er som udgangspunkt stratificeringer efter relevante 
parametre, eksempelvis aldersgruppering eller tidsopdeling. Filerne er 
semicolon-separerede.


Opdateringer:
_______________________________________________________________________________
Filerne bliver opdateret ugentlig om onsdagen. I den forbindelse kan tidsserier også 
ændre sig tilbage i tiden, hvis nyere data foreligger. Derfor anbefales det 
altid at benytte det senest tilgængelige data og for så vidt muligt, ikke at 
gemme filer og lave tidsserier på basis af gamle filer.


Bemærk:
_______________________________________________________________________________
Vær opmærksom på, at datagrundlaget for nye indlæggelser nogle dage ikke kan opdateres.
Det skyldes tekniske udfordringer hos en ekstern leverandør.
Samlet betyder det, at der på nuværende tidspunkt kan være en større dag-til-dag variation af de daglige indlæggelsestal.

* D. 02. februar 2023 har SSI ændret navngivningen fra ’testede personer’ til ’tests’. ’Tests’ dækker over det antal tests (prøver), der er foretaget. Hvis en person har fået foretaget mere end en test pr. dag tæller kun den ene med. /*slettes: En person vil dog ikke tælle med mere end én gang per dag, selv hvis personen har fået foretaget flere tests på én dag.*/
** D. 09. marts 2023 indføres en ny variabel til opgørelse af antal tests i nøgletal 'Antal tests' da den gamle variabel 'antal testede personer' ('antal tests') var fejlbehæftet.

Filerne:
_______________________________________________________________________________


Fil: 01_rsv_noegletal_saeson_region_agegrp
------------------------------------------------------------------------------
Denne benyttes til at beregne nøgletal for hele sæsonen og siden sidste opdatering

Kolonner:
Dato: Dato for udgivelse af data
Sidste opdatering: Dato der sammenlignes med når der skrives "siden sidste opdatering"
Sygdom: RSV - Respiratory syncytial virus
Sæson: RSV sæson
Regionskode: Regionskode for bopælsregion på prøvedato
Region: Bopælsregion på prøvedato inkl. "Alle" (alle regioner)
Aldersgruppe: 0-5 mdr, 6-11 mdr, 1 år, 2 år, 3-5 år, 6-14 år, 15-44 år, 45-64 år, 65-74 år, 75-84 år, 85+ år
Køn: M=mand, K=kvinde, alle=samlet M+K
Antal borgere: Population opgjort pr seneste opdatering fra CPR
Antal førstegangstestede personer: Antal tests hvor personer kun forekommer ved første test
Antal tests: Antallet af tests foretaget (OBS! hvis der er foretaget flere tests pr. dag pr. person så tæller kun en med) 			
Antal Bekræftede tilfælde: Antal Bekræftede tilfælde
Antal nye indlæggelser: Antal nye indlæggelser
Antal døde: Antal døde
Positivprocent: Antal bekræftede tilfælde divideret med antallet af testede personer
Incidens: Antal bekræftede tilfælde divideret med den givne befolkningsstørrelse ganget med 100.000.
Testrate: Antal tests divideret med den givne befolkningsstørrelse ganget med 100.000
Indlæggelsesrate: Antal nye indlæggelser divideret med den givne befolkningsstørrelse ganget med 100.000
timestamp: tidsstempel for dataoprettelse i headeren


Fil: 02_rsv_epikurve_season_region_uge_agegrp 
------------------------------------------------------------------------------
Denne benyttes til at beregne søjlediagrammer (epikurver diverse)

Kolonner:
Sygdom: RSV - Respiratory syncytial virus
Sæson: RSV sæson
Uge: Uge
Regionskode: Regionskode for bopælsregion på prøvedato
Region: Bopælsregion på prøvedato inkl. "Alle" (alle regioner)
Aldersgruppe: 0-5 mdr, 6-11 mdr, 1 år, 2 år, 3-5 år, 6-14 år, 15-44 år, 45-64 år, 65-74 år, 75-84 år, 85+ år
Køn: M=mand, K=kvinde, alle=samlet M+K
Antal borgere: Antal borgere
Antal testede personer: Antal tests* (se teksten under 'Bemærk')
Antal Bekræftede tilfælde: Antal Bekræftede tilfælde	
Antal nye indlæggelser: Antal nye indlæggelser
Antal døde: Antal døde
Positivprocent: Antal bekræftede tilfælde divideret med antallet af testede personer
Bekræftede tilfælde pr. 100.000 borgere: Antal bekræftede tilfælde divideret med den givne befolkningsstørrelse ganget med 100.000
Tests pr. 100.000 borgere: Antal tests divideret med den givne befolkningstørrelse ganget med 100.000
Nye indlæggelser pr. 100.000 borgere: Antal nye indlæggelser divideret med den givne befolkningsstørrelse ganget med 100.000
timestamp: tidsstempel for dataoprettelse i headeren


Fil: 03_rsv_maps_region_agegrp_sex_7days
------------------------------------------------------------------------------
Denne benyttes til at generere diverse kort

Kolonner:
Sygdom: RSV - Respiratory syncytial virus
Regionskode: Regionskode for bopælsregion på prøvedato
Region: Bopælsregion pr. dags dato inkl. "Alle" (alle regioner)					
Aldersgruppe: 0-5 mdr, 6-11 mdr, 1 år, 2 år, 3-5 år, 6-14 år, 15-44 år, 45-64 år, 65-74 år, 75-84 år, 85+ år
Køn: M=mand, K=kvinde, alle=samlet M+K
Antal borgere: Antal borgere
Antal testede personer: Antal tests (7 dage)* (se teksten under 'Bemærk')
Antal Bekræftede tilfælde: Antal Bekræftede tilfælde (7 dage)
Antal nye indlæggelser: Antal nye indlæggelser (7 dage)
Antal døde: Antal døde (7 dage)
Positivprocent: Positivprocent (7 dage)
Bekræftede tilfælde pr. 100.000 borgere: Bekræftede tilfælde pr. 100.000 borgere (7 dage)
Testede personer pr. 100.000 borgere: Testede personer pr. 100.000 borgere (7 dage)
Nye indlæggelser pr. 100.000 borgere: Nye indlæggelser pr. 100.000 borgere (7 dage)
timestamp: tidsstempel for dataoprettelse i headeren